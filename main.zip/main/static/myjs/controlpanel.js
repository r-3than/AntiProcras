var myElement =document.getElementById('code');
function hide(val){document.getElementById('code').placeholder="Locked mouse left container!";}

