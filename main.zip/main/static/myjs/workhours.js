function updateStartHour(val) {
    document.getElementById('StartHour').value=val; 
  }

function updateEndHour(val) {
    document.getElementById('EndHour').value=val; 
  }